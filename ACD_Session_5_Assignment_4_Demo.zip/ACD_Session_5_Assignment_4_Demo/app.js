var Employee1 = {
  Name: "David Hudsen",
  Age: 32,
  Salary: 12000,
  Address: {
    City: "Bangalore",
    State: "Karnataka",
    Pincode: 462030
  }
};
var Employee2 = {
  Name: "Hary Mathew",
  Age: 22,
  Salary: 15000,
  Address: {
    City: "Mumbai",
    State: "Maharashtra",
    Pincode: 210998
  }
};
var Employee3 = {
  Name: "Marry Mads",
  Age: 18,
  Salary: 10000,
  Address: {
    City: "Pune",
    State: "Maharashtra",
    Pincode: 210890
  }
};
var Employee4 = {
  Name: "Gauri Jain",
  Age: 24,
  Salary: 65000,
  Address: {
    City: "Noida",
    State: "UP",
    Pincode: 310890
  }
};
var Employee5 = {
  Name: "Funcky Muth",
  Age: 34,
  Salary: 125000,
  Address: {
    City: "Hyderabad",
    State: "AP",
    Pincode: 540098
  }
};

var Employee = new Array();
Employee[0] = Employee1;
Employee[1] = Employee2;
Employee[2] = Employee3;
Employee[3] = Employee4;
Employee[4] = Employee5;

// Displaying object info on console window
console.log(Employee);

// Printing Array object details of one employee
document.write(Employee[0].Name + ", " + Employee[0].Age + ", " + Employee[0].Salary + ", " +
Employee[0].Address.City + " " + Employee[0].Address.State + " " + Employee[0].Address.Pincode);
